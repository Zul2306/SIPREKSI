
<img src="<?php echo e(asset('assets/images/logo/logo_aplikasi.png')); ?>" alt="Logo" class="<?php echo e($attributes->merge(['class' => 'w-16 h-auto'])); ?>" />

<?php /**PATH C:\laragon\www\TUGASA\frontendd\resources\views/components/application-logo.blade.php ENDPATH**/ ?>