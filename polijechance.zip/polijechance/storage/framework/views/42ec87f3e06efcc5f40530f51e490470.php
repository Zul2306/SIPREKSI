

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Riwayat Prediksi Anda</h1>

    <?php $__empty_1 = true; $__currentLoopData = $predictions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card mb-3">
            <div class="card-header">
                Prediksi #<?php echo e($p->id); ?> <span class="float-end"><?php echo e($p->created_at->format('d M Y H:i')); ?></span>
            </div>
            <div class="card-body">
                <ul>
                    <li>RATA-RATA: <?php echo e($p->rata_rata); ?></li>
                    <li>MAT: <?php echo e($p->mat); ?></li>
                    <li>BIO: <?php echo e($p->bio); ?></li>
                    <li>KIM: <?php echo e($p->kim); ?></li>
                    <li>BIG: <?php echo e($p->big); ?></li>
                    <li>MODEL: <?php echo e($p->filename); ?></li>
                    <li>Nilai Sertifikat: <?php echo e($p->certificate_score ?? '-'); ?></li>
                    <li><strong>Prediksi Kelulusan:</strong> 
                        <?php
                                $score = floatval(str_replace('%', '', $p->result));
                        ?>
                                <span class="badge <?php echo e($score < 50 ? 'bg-danger' : 'bg-success'); ?>">
                            <?php echo e($p->result); ?>

                        </span>
                    </li>

                </ul>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Belum ada prediksi yang selesai diproses.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TUGASA\frontendd\resources\views/user/hasil_prediksi.blade.php ENDPATH**/ ?>